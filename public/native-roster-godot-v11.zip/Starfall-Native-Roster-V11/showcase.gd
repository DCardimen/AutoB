extends Node2D
var forms: Array = []
var selected: int = 0
var state_index: int = 2
var direction: int = 2
var sprite: AnimatedSprite2D
var label: Label
const STATES = ["idle", "walk", "run", "sprint", "turn", "stop", "attack", "slash", "charge", "cast", "dash", "dodge", "hit", "stagger", "knockdown", "getup", "death"]
const DIRECTIONS = ["e", "se", "s", "sw", "w", "nw", "n", "ne"]
func _ready() -> void:
 forms = JSON.parse_string(FileAccess.get_file_as_string("res://manifest.json"))["forms"]
 for form in forms:
  var frames: SpriteFrames = load("res://" + str(form["key"]) + ".tres")
  assert(frames != null and frames.get_animation_names().size() == 136)
 var background := Sprite2D.new()
 background.texture = load("res://environment.png")
 background.centered = false
 background.scale = Vector2(1002.0 / background.texture.get_width(), 654.0 / background.texture.get_height())
 add_child(background)
 sprite = AnimatedSprite2D.new()
 sprite.position = Vector2(501, 375)
 sprite.scale = Vector2(4, 4)
 sprite.centered = false
 sprite.offset = -Vector2(32, 44)
 sprite.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
 add_child(sprite)
 label = Label.new()
 label.position = Vector2(30, 24)
 label.add_theme_color_override("font_color", Color("e9dfbd"))
 add_child(label)
 _show()
 print("Validated " + str(forms.size()) + " native form resources, 136 animations each.")
func _show() -> void:
 sprite.sprite_frames = load("res://" + str(forms[selected]["key"]) + ".tres")
 sprite.play(STATES[state_index] + "_" + DIRECTIONS[direction])
 label.text = "A/D: family form · Space: pose · Q/E: direction · arrows: move · Shift: sprint\n" + str(forms[selected]["key"]) + " · " + STATES[state_index] + " · " + DIRECTIONS[direction]
func _unhandled_key_input(event: InputEvent) -> void:
 if not event is InputEventKey or not event.pressed or event.echo:
  return
 if event.keycode == KEY_A:
  selected = posmod(selected - 1, forms.size())
 if event.keycode == KEY_D:
  selected = (selected + 1) % forms.size()
 if event.keycode == KEY_SPACE:
  state_index = (state_index + 1) % STATES.size()
 if event.keycode == KEY_Q:
  direction = posmod(direction - 1, 8)
 if event.keycode == KEY_E:
  direction = (direction + 1) % 8
 _show()
func _process(delta: float) -> void:
 var move := Vector2(float(Input.is_physical_key_pressed(KEY_RIGHT)) - float(Input.is_physical_key_pressed(KEY_LEFT)), float(Input.is_physical_key_pressed(KEY_DOWN)) - float(Input.is_physical_key_pressed(KEY_UP)))
 if move.length_squared() > 0.0:
  direction = posmod(int(round(move.angle() / (PI / 4.0))), 8)
  sprite.position += move.normalized() * (190.0 if Input.is_physical_key_pressed(KEY_SHIFT) else 115.0) * delta
  sprite.position = sprite.position.clamp(Vector2(80, 150), Vector2(925, 610))
  state_index = 3 if Input.is_physical_key_pressed(KEY_SHIFT) else 2
  _show()
