Extract and open Starfall-Menagerie.html in Chrome, Firefox, or Edge. The complete game, fonts, and three world paintings are embedded. Keep the same file location to retain the device save.
