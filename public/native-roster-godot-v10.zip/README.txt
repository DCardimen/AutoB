Starfall Native Roster v10
Open project.godot in Godot 4. The project uses nearest-neighbor texture filtering.
21 families; 85 base/branch/stage variants; each has 136 animations and 1088 64x64 cells.
A/D: choose form. Space: pose. Q/E: direction. Arrows: move. Shift: sprint.
Authored 100% character height; UI height slider is a cosmetic game preference.
Source regeneration: BASE_URL=<development-server> npm run export:native
